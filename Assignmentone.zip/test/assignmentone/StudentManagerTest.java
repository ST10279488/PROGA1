/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package assignmentone;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lab_services_student
 */
public class StudentManagerTest {
    
    private StudentManager manager;

    public void setUp() {
        // Initialize a new StudentManager before each test
        manager = new StudentManager();
    }
    
   @Test
    public void testSaveStudent() {
        // Create an instance of StudentManager for testing
        StudentManager manager = new StudentManager();

        // Mock user input for a student (replace with your own test data)
        String studentID = "10111";
        String name = "J.Bloggs";
        int age = 19;
        String email = "jbloggs@ymail.com";
        String course = "disd";

        // Redirect System.in to provide the mocked user input
        System.setIn(new ByteArrayInputStream((
                studentID + System.lineSeparator() +
                name + System.lineSeparator() +
                email + System.lineSeparator() +
                course + System.lineSeparator() +
                age + System.lineSeparator()
        ).getBytes()));

        // Create a new Student and add it to the list by calling saveStudent
        manager.saveStudent();

        // Retrieve the student list from the manager
        ArrayList<StudentManager.Student> studentList = manager.studentList;

        // Assert that the list is not empty and contains the student
        assertFalse(studentList.isEmpty());

        // Replace this with appropriate assertions based on your Student class
        // For example:
        StudentManager.Student savedStudent = studentList.get(0);
        assertEquals(studentID, savedStudent.getStudentID());
        assertEquals(name, savedStudent.getName());
        assertEquals(age, savedStudent.getAge());
        assertEquals(email, savedStudent.getEmail());
        assertEquals(course, savedStudent.getCourse());
    }
    public void tearDown() {
        // Reset standard input and output after each test
        System.setIn(System.in);
        System.setOut(System.out);
    }

    
    {
        // Initialize a new StudentManager before each test
        manager = new StudentManager();
    }

    @Test
    public void testSearchStudent() {
        // Create an instance of StudentManager for testing
        StudentManager manager = new StudentManager();

        // Mock user input for a student (replace with your own test data)
        String studentID = "10111";
        String name = "J.Bloggs";
        int age = 19;
        String email = "jbloggs@ymail.com";
        String course = "disd";

        // Create a new Student and add it to the list
       

        // Redirect System.in to provide the mocked user input (student ID to search)
        System.setIn(new ByteArrayInputStream(studentID.getBytes()));

        // Redirect System.out to capture the output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        // Call the searchStudent method
        manager.searchStudent();

        // Restore the standard input and output
        System.setIn(System.in);
        System.setOut(System.out);

        // Retrieve the printed output
        String output = outputStream.toString();

        // Assert that the printed output contains the correct student details
        assertTrue(output.contains("Student found:"));
        assertTrue(output.contains("Student ID: " + studentID));
        assertTrue(output.contains("Name: " + name));
        assertTrue(output.contains("Age: " + age));
        assertTrue(output.contains("Email: " + email));
        assertTrue(output.contains("Course: " + course));
    }
    
{
        // Reset standard input and output after each test
        System.setIn(System.in);
        System.setOut(System.out);
}
    {
        // Initialize a new StudentManager before each test
        manager = new StudentManager();
    }

    @Test
    public void testSearchStudent_StudentNotFound() {
        // Create an instance of StudentManager for testing
        StudentManager manager = new StudentManager();

        // Mock user input for an incorrect student ID (replace with your test data)
        String incorrectStudentID = "12345";

        // Redirect System.in to provide the mocked user input (incorrect student ID)
        System.setIn(new ByteArrayInputStream(incorrectStudentID.getBytes()));

        // Redirect System.out to capture the output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        // Call the searchStudent method
        manager.searchStudent();

        // Restore the standard input and output
        System.setIn(System.in);
        System.setOut(System.out);

        // Retrieve the printed output
        String output = outputStream.toString();

        // Assert that the printed output indicates that no student was found
        assertTrue(output.contains("Student not found."));
    }
{
        // Reset standard input and output after each test
        System.setIn(System.in);
        System.setOut(System.out);
}
    
{
        // Initialize a new StudentManager before each test
        manager = new StudentManager();
    }

    @Test
    public void testDeleteStudent() {
        // Create an instance of StudentManager for testing
        StudentManager manager = new StudentManager();

        // Mock user input for a student (replace with your own test data)
        String studentID = "10111";
        String name = "J.Bloggs";
        int age = 19;
        String email = "jbloggs@ymail.com";
        String course = "disd";

        // Create a new Student and add it to the list
       

        // Redirect System.in to provide the student ID to delete
        System.setIn(new ByteArrayInputStream(studentID.getBytes()));

        // Redirect System.out to capture the output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        // Call the deleteStudent method
        manager.deleteStudent();

        // Restore the standard input and output
        System.setIn(System.in);
        System.setOut(System.out);

        // Retrieve the printed output
        String output = outputStream.toString();

        // Assert that the printed output indicates that the student has been deleted
        assertTrue(output.contains("Student deleted."));
    }
    {
        // Reset standard input and output after each test
        System.setIn(System.in);
        System.setOut(System.out);
    }
    {
        // Initialize a new StudentManager before each test
        manager = new StudentManager();
    } 

    @Test
    public void testDeleteStudent_StudentNotFound() {
        // Create an instance of StudentManager for testing
        StudentManager manager = new StudentManager();

        // Mock user input for an incorrect student ID (replace with your own test data)
        String incorrectStudentID = "12345";

        // Redirect System.in to provide the incorrect student ID to delete
        System.setIn(new ByteArrayInputStream(incorrectStudentID.getBytes()));

        // Redirect System.out to capture the output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));

        // Call the deleteStudent method
        manager.deleteStudent();

        // Restore the standard input and output
        System.setIn(System.in);
        System.setOut(System.out);

        // Retrieve the printed output
        String output = outputStream.toString();

        // Assert that the printed output indicates that no student could be found to delete
        assertTrue(output.contains("Student not found."));
    }
    
 {
        // Reset standard input and output after each test
        System.setIn(System.in);
        System.setOut(System.out);
 }
{
        // Initialize a new StudentManager before each test
        manager = new StudentManager();
    }

    @Test
    public void testSaveStudent_ValidAge() {
        // Create an instance of StudentManager for testing
        StudentManager manager = new StudentManager();

        // Mock user input for a student (replace with your own test data)
        String studentID = "10111";
        String name = "J.Bloggs";
        int age = 19; // A valid age
        String email = "jbloggs@ymail.com";
        String course = "disd";

        // Redirect System.in to provide the mocked user input
        System.setIn(new ByteArrayInputStream((
                studentID + System.lineSeparator() +
                name + System.lineSeparator() +
                email + System.lineSeparator() +
                course + System.lineSeparator() +
                age + System.lineSeparator()
        ).getBytes()));

        // Create a new Student and add it to the list by calling saveStudent
        manager.saveStudent();

        // Retrieve the student list from the manager
        ArrayList<StudentManager.Student> studentList = manager.studentList;

        // Assert that the list is not empty and contains the student
        assertFalse(studentList.isEmpty());

        // Replace this with appropriate assertions based on your Student class
        // For example:
        StudentManager.Student savedStudent = studentList.get(0);
        assertEquals(studentID, savedStudent.getStudentID());
        assertEquals(name, savedStudent.getName());
        assertEquals(age, savedStudent.getAge());
        assertEquals(email, savedStudent.getEmail());
        assertEquals(course, savedStudent.getCourse());
    }
    {
        // Reset standard input and output after each test
        System.setIn(System.in);
        System.setOut(System.out);
    }
    {
        // Initialize a new StudentManager before each test
        manager = new StudentManager();
    }

    @Test
    public void testSaveStudent_InvalidAge() {
        // Create an instance of StudentManager for testing
        StudentManager manager = new StudentManager();

        // Mock user input for a student with an invalid age (less than 16)
        String studentID = "10111";
        String name = "J.Bloggs";
        int age = 13; // An invalid age
        String email = "jbloggs@ymail.com";
        String course = "disd";

        // Redirect System.in to provide the mocked user input
        System.setIn(new ByteArrayInputStream((
                studentID + System.lineSeparator() +
                name + System.lineSeparator() +
                email + System.lineSeparator() +
                course + System.lineSeparator() +
                age + System.lineSeparator()
        ).getBytes()));

        // Create a new Student and add it to the list by calling saveStudent
        manager.saveStudent();

        // Retrieve the student list from the manager
        ArrayList<StudentManager.Student> studentList = manager.studentList;

        // Assert that the list is empty since the student with an invalid age should not be added
        assertTrue(studentList.isEmpty());
    }
{
        // Reset standard input and output after each test
        System.setIn(System.in);
        System.setOut(System.out);
}

 {
        // Initialize a new StudentManager before each test
        manager = new StudentManager();
    }
    @Test
    public void testSaveStudent_InvalidAgeCharacter() {
        // Create an instance of StudentManager for testing
        StudentManager manager = new StudentManager();

        // Mock user input for a student with an age containing non-numeric characters
        String studentID = "10111";
        String name = "J.Bloggs";
        String invalidAge = "abc"; // An invalid age with non-numeric characters
        String email = "jbloggs@ymail.com";
        String course = "disd";

        // Redirect System.in to provide the mocked user input
        System.setIn(new ByteArrayInputStream((
                studentID + System.lineSeparator() +
                name + System.lineSeparator() +
                email + System.lineSeparator() +
                course + System.lineSeparator() +
                invalidAge + System.lineSeparator()
        ).getBytes()));

        // Create a new Student and add it to the list by calling saveStudent
        manager.saveStudent();

        // Retrieve the student list from the manager
        ArrayList<StudentManager.Student> studentList = manager.studentList;

        // Assert that the list is empty since the student with an invalid age should not be added
        assertTrue(studentList.isEmpty());
    }
 {
        // Reset standard input and output after each test
        System.setIn(System.in);
        System.setOut(System.out);
 }
}













    

    


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assignmentone;


import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class StudentManager {

    /**
     * @param args the command line arguments
     */
   
    ArrayList<Student> studentList = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        StudentManager manager = new StudentManager();
        manager.displayMenu();
    }

    class Student {
        private String studentID;
        private String name;
        private int age;
        private String email;
        private final String course;

        // Constructor
        public Student(String studentID, String name, int age, String email, String course) {
            this.studentID = studentID;
            this.name = name;
            this.age = age;
            this.email = email;
            this.course = course;
        }

        // Getters
        public String getStudentID() {
            return studentID;
        }

        public String getName() {
            return name;
        }

        public int getAge() {
            return age;
        }

        public String getEmail() {
            return email;
        }

        public String getCourse() {
            return course;
        }
    }

    public void displayMenu() {
        while (true) {
            System.out.println("1. Capture a new student");
            System.out.println("2. Search for a student");
            System.out.println("3. Delete a student");
            System.out.println("4. Print student report");
            System.out.println("5. Exit Application");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline character

            switch (choice) {
                case 1:
                    saveStudent();
                    break;
                case 2:
                    searchStudent();
                    break;
                case 3:
                    deleteStudent();
                    break;
                case 4:
                    studentReport();
                    break;
                case 5:
                    exitStudentApplication();
                    break;
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        }
    }

    public void saveStudent() {
        System.out.println("Enter student ID:");
        String studentID = scanner.nextLine();

        System.out.println("Enter student name:");
        String name = scanner.nextLine();

        System.out.println("Enter student email:");
        String email = scanner.nextLine();

        System.out.println("Enter the student course:");
        String course = scanner.nextLine();

        int age;
        while (true) {
            System.out.println("Enter student age:");
            try {
                age = Integer.parseInt(scanner.nextLine());
                if (age >= 16) {
                    break;
                } else {
                    System.out.println("Invalid age. Age must be greater than or equal to 16.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number.");
            }
        }

        Student newStudent = new Student(studentID, name, age, email, course);
        studentList.add(newStudent);
        System.out.println("Student details have been successfully saved.");
    }

    public void searchStudent() {
        System.out.println("Enter student ID to search:");
        String searchID = scanner.nextLine();

        boolean found = false;
        for (Student student : studentList) {
            if (student.getStudentID().equals(searchID)) {
                System.out.println("Student found:");
                System.out.println("Student ID: " + student.getStudentID());
                System.out.println("Name: " + student.getName());
                System.out.println("Age: " + student.getAge());
                System.out.println("Email: " + student.getEmail());
                System.out.println("Course: " + student.getCourse());
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Student not found.");
        }
    }

    public void deleteStudent() {
        System.out.println("Enter student ID to delete:");
        String deleteID = scanner.nextLine();

        for (Student student : studentList) {
            if (student.getStudentID().equals(deleteID)) {
                System.out.println("Are you sure you want to delete this student from the system? (yes/no)");
                String confirmation = scanner.nextLine();
                if (confirmation.equalsIgnoreCase("yes")) {
                    studentList.remove(student);
                    System.out.println("Student deleted.");
                } else {
                    System.out.println("Deletion cancelled.");
                }
                return;
            }
        }

        System.out.println("Student not found.");
    }

    public void studentReport() {
        System.out.println("Student Report:");
        for (Student student : studentList) {
            System.out.println("Student ID: " + student.getStudentID());
            System.out.println("Name: " + student.getName());
            System.out.println("Age: " + student.getAge());
            System.out.println("Email: " + student.getEmail());
            System.out.println("Course: " + student.getCourse());
            System.out.println("--------------");
        }
    }

    public void exitStudentApplication() {
        System.out.println("Exiting the application.");
        System.exit(0);
    }
}

/* References

FARRELL, J., 2016. JAVA PROGRAMMING. 8th ed. Boston: s.n.

*/




         
             
            
    
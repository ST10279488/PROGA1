/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package mainapp;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author lab_services_student
 */
public class MainAppTest {
    
    public MainAppTest() {
    }

    @Test
    public void testSomeMethod() {
        
    }
    private shoeShop ShoeShop;
    
    
    public void setUp() {
        // Initialize a new ShoeShop with a max of 3 shoes
        ShoeShop = new shoeShop(3);
        
        
    }

    @Test
    public void testAddShoe() {
        Shoe shoe1 = new Shoe(1, "Gucci", "Louis Vuitton");
        Shoe shoe2 = new Shoe(2, "Prada", "Saint Laurent");
        Shoe shoe3 = new Shoe(3, "Nike", "Adidas");

        // Add shoes
        ShoeShop.addShoe(shoe1);
        ShoeShop.addShoe(shoe2);

        // Check if shoes were added successfully
        assertEquals(2, ShoeShop.getTotalShoes());

        // Add one more shoe, which should exceed the max
        ShoeShop.addShoe(shoe3);

        // Check if the cart is still limited to the max
        assertEquals(2, ShoeShop.getTotalShoes());
    }

    @Test
    public void testCheckOutShoe() {
        Shoe shoe1 = new Shoe(1, "Gucci", "Louis Vuitton");
        Shoe shoe2 = new Shoe(2, "Prada", "Saint Laurent");

        // Add shoes 
        ShoeShop.addShoe(shoe1);
        ShoeShop.addShoe(shoe2);

        // Check out a shoe
        ShoeShop.checkOutShoe(1);

        // Verify that the shoe was checked out
        assertTrue(shoe1.isCheckedOut());

        // Try to check out a shoe that's already checked out
        ShoeShop.checkOutShoe(1);

        // Verify that it remains checked out
        assertTrue(shoe1.isCheckedOut());
    }

    @Test
    public void testReturnShoe() {
        Shoe shoe1 = new Shoe(1, "Gucci", "Louis Vuitton");
        Shoe shoe2 = new Shoe(2, "Prada", "Saint Laurent");

        // Add shoes 
        ShoeShop.addShoe(shoe1);
        ShoeShop.addShoe(shoe2);

        // Check out and then return a shoe
        ShoeShop.checkOutShoe(1);
        ShoeShop.returnShoe(1);

        // Verify that the shoe is returned
        assertFalse(shoe1.isCheckedOut());

        // Return a shoe that's already in the cart
        ShoeShop.returnShoe(1);

        // Verify that it remains returned
        assertFalse(shoe1.isCheckedOut());
    }
}



    
    


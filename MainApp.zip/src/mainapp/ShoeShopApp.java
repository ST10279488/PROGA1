/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainapp;

/**
 *
 * @author lab_services_student
 */
public class ShoeShopApp {
    private int shoeId;
    private String brand;
    private String designer;
    private boolean checkedOut;

    public ShoeShopApp(int shoeId, String brand, String designer) {
        this.shoeId = shoeId;
        this.brand = brand;
        this.designer = designer;
        this.checkedOut = false;
    }

    // Getter and setter methods
    public int getShoeId() {
        return shoeId;
    }

    public String getBrand() {
        return brand;
    }

    public String getDesigner() {
        return designer;
    }

    public boolean isCheckedOut() {
        return checkedOut;
    }

    public void setCheckedOut(boolean checkedOut) {
        this.checkedOut = checkedOut;
    }

    private Shoe[] catalog;
    private int totalShoes;

    public ShoeShopApp(int maxShoes) {
        catalog = new Shoe[maxShoes];
        totalShoes = 0;
    }

    public void addShoe(Shoe shoe) {
        if (totalShoes < catalog.length) {
            catalog[totalShoes] = shoe;
            totalShoes++;
        } else {
            System.out.println("Cart is full. Cannot add more shoes.");
        }
    }

    public void checkOutShoe(int shoeId) {
        for (int i = 0; i < totalShoes; i++) {
            if (catalog[i].getShoeId() == shoeId) {
                if (!catalog[i].isCheckedOut()) {
                    catalog[i].setCheckedOut(true);
                    System.out.println("Shoes checked out successfully.");
                } else {
                    System.out.println("Shoes are already checked out.");
                }
                return;
            }
        }
        System.out.println("Shoes not found in the cart.");
    }

    public void returnShoe(int shoeId) {
        for (int i = 0; i < totalShoes; i++) {
            if (catalog[i].getShoeId() == shoeId) {
                if (catalog[i].isCheckedOut()) {
                    catalog[i].setCheckedOut(false);
                    System.out.println("Shoes returned successfully.");
                } else {
                    System.out.println("Shoes are already in the cart.");
                }
                return;
            }
        }
        System.out.println("Shoes not found in the cart.");
    }

    public void generateReport() {
        System.out.println("Shoe shop Catalog:");
        for (int i = 0; i < totalShoes; i++) {
            System.out.println("Shoe ID: " + catalog[i].getShoeId());
            System.out.println("Brand: " + catalog[i].getBrand());
            System.out.println("Designer: " + catalog[i].getDesigner());
            System.out.println("Status: " + (catalog[i].isCheckedOut() ? "Checked Out" : "Available"));
            System.out.println("-----------------------");
        }
    }
}



